Want to contribute?

We regret that we are currently unable to accept contributions to python-gflags
due to some technical issues.

If you have a problem you'd like to have solved, please open a
[GitHub issue](https://github.com/google/python-gflags/issues) and we'll try to
resolve it.

Because we can't accept contributions right now, pull requests will be closed
without review.
